Sarah Turner(turnesar) - CS344/PROJECT 3

compile using this line:
gcc -o smallsh smallsh.c

Then run smallsh executable